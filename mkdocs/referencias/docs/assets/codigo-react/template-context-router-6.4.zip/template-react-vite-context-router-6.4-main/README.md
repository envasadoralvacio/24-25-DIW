# Template React + Vite + Context + Router v6.4

Template base para projetos React con Context API e React Router v6.4
