<template>
  <h2>Personajes</h2>
</template>
