<template>
  <div class="pokemon-layout">
    <h1>Pokemon Layout</h1>
    <router-view />
  </div>
</template>

<script>
export default {}
</script>

<style scoped>
.pokemon-layout {
  background-color: deeppink;
}
</style>
