<template>
  <h1>Error 404 Not Found</h1>
</template>
