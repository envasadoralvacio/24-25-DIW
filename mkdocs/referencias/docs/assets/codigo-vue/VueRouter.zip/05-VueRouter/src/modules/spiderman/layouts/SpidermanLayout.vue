<template>
  <div class="spiderman-layout">
    <h1>Spiderman Layout</h1>
    <router-view />
  </div>
</template>

<script>
export default {}
</script>

<style scoped>
.spiderman-layout {
  background-color: deepskyblue;
}
</style>
