<template>
  <h2>About Spiderman</h2>
</template>
