export default () => ({
  count: 1,
  lastMutation: 'none',
  isLoading: false,
})
