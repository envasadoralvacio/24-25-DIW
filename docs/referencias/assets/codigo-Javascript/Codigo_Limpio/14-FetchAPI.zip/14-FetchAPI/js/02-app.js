// Fetch API desde un JSON (Objeto)
