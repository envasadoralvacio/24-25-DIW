<template>
  <h1 v-if="!pokemon">Espere por favor...</h1>
  <!-- <div v-if="pokemon"> -->
  <div v-else="pokemon">
    <h1>¿Quien es este pokemon?</h1>

    <PokemonPicture :pokemonId="pokemon.id" :showPokemon="showPokemon" />

    <PokemonOptions :pokemons="pokemonsArr" />
  </div>
</template>

<script>
import PokemonOptions from '../components/PokemonOptions.vue'
import PokemonPicture from '../components/PokemonPicture.vue'
import getPokemonOptions from '@/helpers/getPokemonOptions'

export default {
  components: { PokemonOptions, PokemonPicture },
  data() {
    return {
      pokemonsArr: [],
      pokemon: null,
      // pokemon: {},
      showPokemon: false,
    }
  },
  methods: {
    async mixPokemonArray() {
      this.pokemonsArr = await getPokemonOptions()
      const rndInt = Math.floor(Math.random() * 4)
      // console.log(rndInt)
      this.pokemon = this.pokemonsArr[rndInt]
    },
  },
  mounted() {
    this.mixPokemonArray()
  },
}
</script>

<style></style>
