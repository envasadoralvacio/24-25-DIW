const getPokemons = () => {
  const pokemosArr = Array.from(Array(650))
  // console.log(pokemosArr)
  return pokemosArr.map((arg, index) => index + 1)
}

const getPokemonOptions = () => {
  // getPokemons()
  // console.log(Math.random())
  const mixedPokemons = getPokemons().sort(() => Math.random() - 0.5)
  // console.log(getPokemons())
  // console.log(mixedPokemons)
  getPokemonName(mixedPokemons.splice(0, 4))
}

// const getPokemonName = (pokemons = []) => {
//   console.log(pokemons)
// }

const getPokemonName = ([a, b, c, d] = []) => {
  console.log(a, b, c, d)
}

export default getPokemonOptions
